#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
struct cordinate
{
    int x;
    int y;
};
class child
{
  public:
    child();
    int stamina;
    int wait;
    bool IsFreez;
    bool IsScared;
    bool IsHandFull;
    bool IsAtHome;
    cordinate position;
};
class gameSetting
{
public:
    std::vector<int> config;
    std::vector<std::string> static_map;
    void loadFiles();
};

class game
{
  private:
    std::vector<int> config;
    std::vector<std::string> static_map;
    std::vector<std::string> game_dynamic_nap;
    std::vector<cordinate> routes[7];
    std::vector<cordinate>::iterator iterators[7];
    int objectList[8][2];
    std::vector<cordinate> ghostList;
    int ghostNum = 0;
    child nokhodies[7];

  public:
    game(std::vector<std::string> &map,std::vector<int> config);
    bool findPath(std::vector<std::string> &tmap, int number, int y, int x);
    void findAllPaths();
    void extractObjectCordinates();
    void printmap();
    void refreshGhosts();
    int getGameTime();
    int getChildInitialStamina(int num);
    void updateChildren();
    void checkState();
    int remainingObjectives();
    cordinate homePosition();
};