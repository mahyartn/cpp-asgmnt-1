#include "game.h"
int main()
{
    srand(time(NULL));
    //std::cout << "test";
    gameSetting game1;
    game1.loadFiles();
    game test(game1.static_map,game1.config);
    test.extractObjectCordinates();
    test.findAllPaths();
    test.refreshGhosts();
    test.printmap();
    for (int i = 0; i <= test.getGameTime(); i++)
    {
        test.refreshGhosts();
        test.updateChildren();
        test.checkState();
        system("clear");
        test.printmap();
        std::cout << "Time remaining :" << (test.getGameTime() - i) << " Remaining Objectives:" << test.remainingObjectives() << '\n';
        usleep(100000);
    }
}
